# WeatherPeg

## Your one-stop shop for the current weather in Winnipeg

Everything is included, just run the .exe

https://discord.gg/2M4PxAuQt8

Official server of WeatherPeg

source.txt is where you put the link to the XML file for information sourcing. Examples in examples.txt. 
